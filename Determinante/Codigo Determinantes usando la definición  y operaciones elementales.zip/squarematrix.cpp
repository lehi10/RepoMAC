/*Author: Lehi Quincho Mamani
 * Universidad Nacional de San Agustín
 * Matematica aplicada a la Computación
 * Determinantes usando la reducción a una matriz escalonada con Gauss  (metodo iterativo)
 * Determinantes usando el metodo de Cofactores (Metodo recursivo)
 *
 * El programa ha sido desarrollado en C++ , y para poder probarlo se necesita compilar el archivo main.cpp
 *  con los otros dos archivos que son parte del proyecto que son squarematrix.h y squarematrix.cpp (clase creada para matrices cuadradas).
 *  Las funciones se encuentran dentro de la clase ScuaqueMatrix con los nombres de det_echelon (determinante por medio de la matriz escalonada)
 *  y det_Rec (Determinante por medio de Cofactores).
 *
*/

#include "squarematrix.h"
#include <math.h>
#include <iostream>
using namespace std;


SquareMatrix::SquareMatrix(int n)
{
    this->N=n;
    matrix=new float *[n];
    for(int i=0;i<n;i++)
    {
        matrix[i]=new float[n];
        for(int j=0;j<n;j++)
        {
            cin>>matrix[i][j];
        }
    }

}

float ** SquareMatrix::create_matrix(int dim)
{
    matrix=new float *[dim];
    for(int i=0;i<dim;i++)
        matrix[i]=new float[dim];
    return matrix;
}




float SquareMatrix::det_Recursive(float **subMatrix,int n)
{

    if(n==1)
        return subMatrix[0][0];

    if(n==2)
        return (subMatrix[0][0]*subMatrix[1][1]) - (subMatrix[0][1]*subMatrix[1][0]);

    float res=0;
    for(int i=0;i<n;i++)
    {
        float ** childMatrix=create_matrix(n-1);

        int j=0;
        for(int row=1;row<n;row++)
        {
            int k=0;
            for(int col=0;col<n;col++)
            {
                if(i != col)
                {
                    childMatrix[j][k]=subMatrix[row][col];
                    k++;
                }
            }
            j++;
        }
        float detA=det_Recursive(childMatrix,n-1);
        res+= subMatrix[0][i]  * pow(-1,(i+1)+1) * detA ;

    }

    return res;
}

float SquareMatrix::det_Rec()
{
    float res=det_Recursive(this->matrix,this->N);
    cout<< "la determinante de la matriz usando el metodo recursivo es :"<<res<<endl;
    return res;
}

float SquareMatrix::det_echelon()
{

    for(int i=0;i<N-1;i++)
    {
        for(int j=i+1;j<N;j++)
        {
            float mult=(matrix[j][i]*(-1))/matrix[i][i];
            for(int k=0;k<N;k++)
                matrix[j][k] += (matrix[i][k]*mult) ;
        }
    }
    float res=1;
    for(int i=0;i<N;i++)
        res*=matrix[i][i];
    cout<<"La determinante reduciendo la matriz a una matriz escalonada es  : "<<res<<endl;
    return res;
}

void SquareMatrix::print_matrix()
{
    cout<<"Matriz : "<<endl;
    for(int i=0;i<N;i++)
    {
        for(int j=0;j<N;j++)
            cout<<matrix[i][j]<<"  ";
        cout<<endl;
    }

}
